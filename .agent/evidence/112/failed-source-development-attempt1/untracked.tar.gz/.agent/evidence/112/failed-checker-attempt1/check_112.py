#!/usr/bin/env python3
"""Independent feature112 documentary checks. Semantic truth requires human review.

Development modes do not consume future QA outputs. --semantic-review and
--integrity require the independently sealed candidate and personally captured
primary sources. --negative mutates only an owned TemporaryDirectory overlay,
checks the intended diagnostic, then rechecks its restored positive control.
"""
import argparse
import copy
import difflib
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path
from urllib.parse import urlparse

import yaml

BASE = '7d852bd7aedde01d7739126aa7a1cf880534a410'
PHASE_BASE = 'da1131846815328890cfb509be608551b80a82a7'
CONTRACT_HASH = '4357e16ce1423d7fa20bbec7ed4a008700e0046b29fe3789c8a78bb1cb87caca'
APPROVED_BASE_HASH = '99fc6e5dbd2b98accac1a29a0f2419ceefdb4c2a46744fe4be244a158223c177'
ROOT = Path(__file__).resolve().parents[3]
E = '.agent/evidence/112/'
DOC = 'methodology/11_sbcl_runtime_binding.md'
PRODUCTS = [DOC, 'NIZAM.json', 'methodology/README.md',
            'methodology/10_live_runtime_sessions.md', 'CHANGELOG.md',
            'docs/nips/NIP-0003-live-runtime-sessions.md', 'docs/planning/HANDOVER.md',
            'docs/planning/ROADMAP.md', 'docs/planning/backlog_reconciliation.md']
PARENT = ['.agent/feature_list_015.json', 'docs/planning/phase_015.yaml',
          'docs/planning/backlog_dag.json', 'docs/planning/manifest.json',
          '.agent/run_state.json']
VERSIONS = {'methodology/README.md': '0.6.0',
            'methodology/10_live_runtime_sessions.md': '0.1.2',
            'docs/nips/NIP-0003-live-runtime-sessions.md': '1.1.1',
            'docs/planning/HANDOVER.md': '1.0.8', 'docs/planning/ROADMAP.md': '0.59.1',
            'docs/planning/backlog_reconciliation.md': '0.1.13'}
CHECKER_FILES = [E+'check_112.py', E+'controls.json']
BASE_BYTES = {}


class Rejection(Exception):
    def __init__(self, code, detail):
        self.code, self.detail = code, detail
        super().__init__(code+': '+detail)


def need(ok, code, detail):
    if not ok:
        raise Rejection(code, detail)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    p = subprocess.run(['git', '-C', str(ROOT), *args], capture_output=True)
    need(p.returncode == 0, 'setup-git', p.stderr.decode(errors='replace'))
    return p.stdout


class View:
    def __init__(self, overlay=None):
        self.overlay = overlay
        self.cache = {}

    def read(self, path):
        need(not Path(path).is_absolute() and '..' not in Path(path).parts,
             'setup-path', path)
        p = self.overlay / path if self.overlay else None
        if p and p.is_file():
            return p.read_bytes()
        p = ROOT / path
        need(p.is_file(), 'missing-document' if path == DOC else 'setup-missing', path)
        need(not p.is_symlink(), 'scope-symlink', path)
        return p.read_bytes()

    def text(self, path):
        return self.read(path).decode('utf-8')

    def obj(self, path):
        return json.loads(self.read(path))

    def base(self, path, revision=BASE):
        if revision not in BASE_BYTES:
            with tarfile.open(fileobj=io.BytesIO(git('archive', revision))) as archive:
                BASE_BYTES[revision] = {m.name: archive.extractfile(m).read()
                                        for m in archive if m.isfile()}
        need(path in BASE_BYTES[revision], 'setup-base-path', path)
        return BASE_BYTES[revision][path]

    def base_obj(self, path):
        return json.loads(self.base(path))

    def paths(self):
        tracked = set(git('ls-tree', '-r', '--name-only', BASE).decode().splitlines())
        present = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*')
                   if p.is_file() and '.git' not in p.relative_to(ROOT).parts}
        if self.overlay:
            present |= {p.relative_to(self.overlay).as_posix() for p in self.overlay.rglob('*')
                        if p.is_file()}
        return tracked, present


def contract(v):
    need(sha(v.read(E+'approved-base.json')) == APPROVED_BASE_HASH, 'approved-base', 'immutable pre-write base receipt')
    need(sha(v.read('.agent/contracts/112.json')) == CONTRACT_HASH, 'approved-contract', '112 contract changed')
    c = v.obj('.agent/contracts/112.json')
    need(c['status'] == 'approved' and all(c['approvals'][k] for k in
         ('validator_mode_a', 'evaluator_contract_review')), 'approved-contract', 'independent gates')
    return c


def prose(text):
    text = re.sub(r'<!--.*?-->', '', text, flags=re.S)
    text = re.sub(r'(?ms)^```[^\n]*\n.*?^```\s*$', '', text)
    return re.sub(r'\s+', ' ', text)


def markdown(text):
    m = re.match(r'\A---\n(.*?)\n---\n(.*)\Z', text, re.S)
    need(m is not None, 'document-frontmatter', 'missing YAML frontmatter')
    return yaml.safe_load(m[1]), m[2]


def sections(v):
    c = contract(v)
    text = v.text(DOC)
    fm, body = markdown(text)
    need(fm.get('version') == '0.1.0' and fm.get('status') == 'active' and
         fm.get('enforcement') == 'consumer-aspirational' and
         fm.get('authoritative_source') == DOC, 'document-frontmatter', 'binding identity')
    headings = re.findall(r'(?m)^## .*$', body)
    need(headings == c['implementation_requirements']['sections'], 'section-set', 'exact eleven sections/order')
    spans = {}
    for i, heading in enumerate(headings):
        start = body.index(heading) + len(heading)
        end = body.index(headings[i+1]) if i+1 < len(headings) else len(body)
        spans[i+1] = body[start:end]
        need(prose(spans[i+1]).strip(), 'section-empty', heading)
    return spans


def structure(v):
    spans = sections(v)
    controls = v.obj(E+'controls.json')
    for rule in controls['section_rules']:
        span = prose(spans[rule['section']])
        need(re.search(r'\b(MUST|SHALL|REQUIRED)\b', span), 'normative-rule', rule['topic'])
        for pattern in rule['patterns']:
            need(re.search(pattern, span, re.I), 'section-token', rule['topic']+' / '+pattern)
    boundary = prose(spans[1]+' '+spans[9])
    need(re.search(r'illustrative', boundary, re.I) and re.search(r'phase\s*016|feature\s*118', boundary, re.I)
         and re.search(r'pending|future|not .*proof', boundary, re.I), 'live-boundary', 'ASDF/live proof boundary')
    need(not re.search(r'(?:all thirteen|all 13|live conformance|runtime conformance)\s+(?:cases\s+)?(?:are\s+)?(?:proved|proven|passed|complete|verified)',
                       prose(' '.join(spans.values())), re.I), 'live-boundary', 'unsupported live promotion')
    need(not re.search(r'join-thread[^.]*\bMUST\s+mark\s+the\s+operation\s+cancelled',
                       prose(spans[8]), re.I), 'timeout-semantics', 'wait deadline cannot confirm cancellation')
    need(not re.search(r'\bMUST\s+reuse\s+(?:the\s+)?shared\s+ASDF\s+cache',
                       prose(spans[9]), re.I), 'fresh-cache-policy', 'fresh private empty build cache required')
    mapping = spans[10]
    rows = [line.split('|')[1:-1] for line in mapping.splitlines() if line.startswith('|')]
    statuses = v.obj('schema/runtime_operation.schema.json')['properties']['status']['enum']
    names = []
    for row in rows:
        cells = [x.strip().strip('`') for x in row]
        if cells and cells[0] in statuses:
            need(len(cells) >= 2 and prose(cells[1]).strip(), 'outcome-mapping', cells[0])
            names.append(cells[0])
    need(sorted(names) == sorted(statuses), 'outcome-mapping', 'exact eight delivered status rows')
    need(not re.search(r'`(?:queued|infrastructure_failed)`', mapping), 'outcome-mapping', 'invented record status')
    urls = re.findall(r'https://[^\s)>]+', spans[11])
    hosts = {urlparse(x).hostname for x in urls}
    need({'www.lispworks.com', 'www.sbcl.org', 'asdf.common-lisp.dev'} <= hosts,
         'primary-references', 'official CLHS/SBCL/ASDF links')
    registration(v)
    bounded_documents(v)


def registration(v):
    old = v.base_obj('NIZAM.json'); new = copy.deepcopy(v.obj('NIZAM.json'))
    caps = [x for x in new['capabilities'] if x['id'] == 'nizam-sbcl-runtime-binding']
    need(len(caps) == 1 and caps[0]['authoritative_source'] == DOC and bool(caps[0].get('summary')),
         'registration', 'binding capability')
    new['capabilities'].remove(caps[0])
    modules = [x for x in new['modules'] if x['path'] == 'methodology']
    need(len(modules) == 1 and modules[0]['key_documents'].count(DOC) == 1,
         'registration', 'methodology key_documents')
    modules[0]['key_documents'].remove(DOC)
    need(new == old, 'index-delta', 'all preexisting index fields preserved')


def strip_version(v, path):
    old = v.base(path).decode(); new = v.text(path)
    oldfm, _ = markdown(old); fm, _ = markdown(new)
    need(fm.get('version') == VERSIONS[path], 'version-delta', path)
    need(isinstance(fm.get('change_log'), list) and len(fm['change_log']) == len(oldfm['change_log'])+1,
         'changelog-delta', path)
    first = fm['change_log'][0]
    need(first.get('version') == VERSIONS[path] and bool(first.get('date')) and bool(first.get('summary')),
         'changelog-delta', path+' new record')
    need(fm['change_log'][1:] == oldfm['change_log'], 'historical-log', path)
    # Preserve the exact old frontmatter bytes, including logs, after one inserted record.
    entries = list(re.finditer(r'(?m)^  - version:', new.split('\n---\n',1)[0]))
    need(len(entries) >= 2, 'changelog-delta', path+' entries')
    normalized = new[:entries[0].start()] + new[entries[1].start():]
    normalized = re.sub(r'(?m)^version: '+re.escape(VERSIONS[path])+r'$',
                        'version: '+str(oldfm['version']), normalized, count=1)
    need(normalized.split('\n---\n',1)[0] == old.split('\n---\n',1)[0],
         'historical-log', path+' frontmatter bytes')
    return old, normalized


def availability_cut(text):
    start = text.index('# Live Runtime Sessions\n\n') + len('# Live Runtime Sessions\n\n')
    end = text.index('\n\nA runtime session', start)
    first = text[start:end]
    text = text[:start] + '<availability>' + text[end:]
    marker = 'preserve fields they do not own.'
    start = text.index(marker, text.index('## 12. Durable records'))+len(marker)
    end = text.index('\n\n| requirement-id', start)
    second = text[start:end]
    return text[:start]+'<availability>'+text[end:], first+' '+second


def bounded_documents(v):
    c = contract(v)
    a = c['implementation_requirements']['activation_clarification']
    for path, count in a['occurrences'].items():
        old, new = strip_version(v, path)
        need(old.count(a['old']) == count and new.count(a['new']) == count and a['old'] not in new,
             'activation-truth', path)
        new = new.replace(a['new'], a['old'])
        if path == 'docs/nips/NIP-0003-live-runtime-sessions.md':
            n = c['implementation_requirements']['nip_acceptance_clarification']
            need(new.count(n['new']) == 1 and n['old'] not in new, 'acceptance-truth', path)
            new = new.replace(n['new'], n['old'])
        need(new == old, 'bounded-document', path)
    path = 'methodology/README.md'; old, new = strip_version(v, path)
    added = [line for line in new.splitlines(True) if DOC.split('/')[-1] in line]
    need(len(added) == 1 and added[0].startswith('|') and 'SBCL' in added[0], 'registration', 'README Document11 row')
    new = new.replace(added[0], '', 1)
    def opening(t):
        s = t.index('The `methodology/` module'); e = t.index('\n\n| File', s)
        return t[:s]+'<opening>'+t[e:], t[s:e]
    oldnorm, _ = opening(old); newnorm, description = opening(new)
    need('SBCL' in description and re.search(r'neutral|runtime-agnostic', description, re.I), 'index-description', 'neutral plus reference binding')
    need(oldnorm == newnorm, 'bounded-document', path)
    path = 'methodology/10_live_runtime_sessions.md'; old, new = strip_version(v, path)
    oldnorm, _ = availability_cut(old); newnorm, available = availability_cut(new)
    need(oldnorm == newnorm, 'bounded-document', path+' immutable R1-R12/other body')
    need(re.search(r'SBCL', available) and re.search(r'deliver|publish|available|reference binding', available,re.I)
         and re.search(r'pending|future', available,re.I) and re.search(r'113',available)
         and re.search(r'115[–-]120|016',available), 'availability-truth', path)
    path = 'CHANGELOG.md'; old = v.base(path).decode(); new = v.text(path)
    added = list(difflib.SequenceMatcher(None, old.splitlines(True), new.splitlines(True), autojunk=False).get_opcodes())
    insertions = [x for x in added if x[0] != 'equal']
    need(len(insertions) == 1 and insertions[0][0] == 'insert', 'changelog-delta', 'one inserted112 entry')
    _, a0, _, b0, b1 = insertions[0]; text = ''.join(new.splitlines(True)[b0:b1])
    need(old.index('## [Unreleased]') < len(''.join(old.splitlines(True)[:a0])) < old.index('## [1.5.0]')
         and '112' in text and 'SBCL' in text and len(text.split()) <= 180,
         'changelog-delta', 'bounded Unreleased112 entry')


def scope(v):
    contract(v)
    tracked, present = v.paths()
    for path in sorted(tracked | present):
        allowed_new = path == DOC or path.startswith(E) or bool(re.fullmatch(r'\.agent/(?:qa|validator)/112(?:-[\w-]+)?\.json', path))
        if path in tracked:
            if path in PRODUCTS or path in PARENT:
                continue
            need(path in present and v.read(path) == v.base(path), 'historical-immutable' if path.startswith('.agent/') else 'scope-path', path)
        else:
            need(allowed_new, 'scope-path', path)
    registration(v); bounded_documents(v); lifecycle(v)


def historical(v):
    tracked, present = v.paths()
    # All pre-existing112 gates/raw evidence are also immutable; future112 outputs may be new.
    for path in sorted(tracked):
        if path in PRODUCTS or path in PARENT:
            continue
        need(path in present and v.read(path) == v.base(path), 'historical-immutable', path)
    installed = [p for p in tracked if p.startswith('.nizam/')]
    need(len(installed) == 239, 'installed-inventory', str(len(installed)))
    need({p for p in present if p.startswith('.nizam/')} == set(installed), 'installed-inventory', 'exact239 payload paths')
    registration(v); bounded_documents(v)


def drop(d, fields):
    return {k: x for k, x in d.items() if k not in fields}


def approved_block(obj):
    return obj.get('final_verdict', {}).get('approved') is True and all(obj.get(k) == [] for k in
                ('issues', 'missing_acceptance_coverage', 'unsupported_claims'))


def completion(v):
    modeb = v.obj('.agent/validator/112-mode-b.json'); qa = v.obj('.agent/qa/112.json')
    need(approved_block(modeb) and approved_block(qa) and qa.get('qa_pass') is True and
         qa.get('checks_run') == 20 and qa.get('checks_passed') == 20,
         'early-completion', 'actual ModeB and independent20/20 QA')
    need(qa.get('adversarial', {}).get('performed') is True, 'early-completion', 'independent spot-check')
    gate = v.obj(E+'evidence-gate.json')
    need(gate.get('passed') is True and gate.get('checks') == 20 and
         gate.get('qa_sha256') == sha(v.read('.agent/qa/112.json')) and
         gate.get('qa_inputs_sha256') == sha(v.read(E+'qa-inputs.json')),
         'early-completion', 'actual hash-bound evidence gate')
    c = contract(v)
    need(set(gate.get('evidence_files', [])) == {x['evidence'] for x in c['verification']},
         'early-completion', 'every required numbered receipt')
    for x in c['verification']:
        raw = v.text(x['evidence'])
        need(x['command'] in raw and re.search(r'(?m)^EXIT\s*:\s*0\s*$',raw),
             'early-completion', x['evidence']+' command/actual EXIT')
    integrity(v); semantic_review(v)


def lifecycle(v):
    contract(v)
    path = '.agent/feature_list_015.json'; old = v.base_obj(path); new = v.obj(path)
    need(drop(old,['features']) == drop(new,['features']), 'canonical-plan', 'top-level phase/list metadata')
    need(len(old['features']) == len(new['features']), 'canonical-plan', 'feature count')
    current = None
    fields = ['status','passes','contract_ref','qa','evidence','completed_at','failure_evidence']
    for a,b in zip(old['features'],new['features']):
        if a['id'] == '112':
            current = b
            need(drop(a,fields) == drop(b,fields), 'canonical-plan', '112 AC/dependencies/estimates')
        else:
            need(a == b, 'canonical-plan', 'unrelated feature '+a['id'])
    need(current['status'] in ('in_progress','complete'), 'lifecycle-stage', current['status'])
    complete = current['status'] == 'complete'
    need(current.get('passes') is complete and current.get('contract_ref') == '.agent/contracts/112.json',
         'lifecycle-stage', 'passes/contract projection')
    path = 'docs/planning/phase_015.yaml'; old = yaml.safe_load(v.base(path)); new = yaml.safe_load(v.read(path))
    need(drop(old,['steps']) == drop(new,['steps']) and len(old['steps']) == len(new['steps']), 'canonical-plan', 'phase identity/budget')
    for a,b in zip(old['steps'],new['steps']):
        if a['id'] == '112':
            need(drop(a,['status','evidence','docs_updated','changelog_entry']) == drop(b,['status','evidence','docs_updated','changelog_entry'])
                 and b['status'] == ('COMPLETED' if complete else 'IN_PROGRESS'), 'lifecycle-stage', 'phase112')
        else: need(a == b, 'canonical-plan', 'phase unrelated step')
    path = 'docs/planning/manifest.json'
    need(v.obj(path) == v.base_obj(path), 'canonical-plan', 'manifest fixed after activation')
    path = 'docs/planning/backlog_dag.json'; old = v.base_obj(path); new = v.obj(path)
    need(drop(old,['packets']) == drop(new,['packets']) and len(old['packets']) == len(new['packets']), 'canonical-plan', 'DAG edges/global fields')
    for a,b in zip(old['packets'],new['packets']):
        if a['id'] == 'NIP3-112':
            need(drop(a,['status','authority_status','prerequisites','evidence']) == drop(b,['status','authority_status','prerequisites','evidence']), 'canonical-plan', '112 packet immutable fields')
            need(b['status'] == ('complete' if complete else 'in_progress'), 'lifecycle-stage', '112 packet')
            need(b['prerequisites']['technical'] == a['prerequisites']['technical'] and b['prerequisites']['environment'] == a['prerequisites']['environment'], 'canonical-plan', '112 prior technical/environment')
            need(b['prerequisites']['authority']['satisfied'] is True and b['prerequisites']['evidence']['satisfied'] is complete, 'lifecycle-stage', '112 authority/evidence')
        elif a['id'] == 'NIP3-113' and complete:
            need(drop(a,['prerequisites']) == drop(b,['prerequisites']), 'canonical-plan', '113 stays pending/immutable')
            need(drop(a['prerequisites'],['technical']) == drop(b['prerequisites'],['technical']) and b['prerequisites']['technical']['satisfied'] is True, 'canonical-plan', '113 predecessor only')
        else: need(a == b, 'canonical-plan', 'unrelated packet '+a['id'])
    path = '.agent/run_state.json'; old = v.base_obj(path); new = v.obj(path)
    need(new['history'][:len(old['history'])] == old['history'], 'history-prefix', 'all original history values')
    for key, counter in old['circuit_breaker'].items():
        now = new['circuit_breaker'].get(key)
        if key.startswith('112-'):
            need(isinstance(now,dict) and now.get('limit') == 3 and counter['attempts'] <= now.get('attempts',-1) <= 3,
                 'counter-continuity', key)
        else: need(now == counter, 'counter-continuity', key)
    need(set(new['circuit_breaker']) == set(old['circuit_breaker']), 'counter-continuity', 'undeclared counters')
    mutable = ['history','circuit_breaker','scope_budget','updated_at','current_feature','active_contract_id','last_action','completed_contract_ids']
    need(drop(old,mutable) == drop(new,mutable), 'state-preservation', 'unowned state fields/pins/ledgers')
    need(new['current_feature'] == ('113' if complete else '112') and new['active_contract_id'] == (None if complete else '112'), 'lifecycle-stage', 'derived position')
    need(new['completed_contract_ids'] == old['completed_contract_ids']+(['112'] if complete else []), 'lifecycle-stage', 'completion ledger')
    if complete:
        try: completion(v)
        except (FileNotFoundError, Rejection, ValueError, KeyError) as exc:
            raise Rejection('early-completion', str(exc)) from exc


def budget(v):
    old = v.base_obj('.agent/run_state.json')['scope_budget']; now = v.obj('.agent/run_state.json')['scope_budget']
    need(old['original_estimate_lines'] == now['original_estimate_lines'] == 7200 and old['ceiling_130pct'] == now['ceiling_130pct'] == 9360,
         'budget-authority', '7200/9360 unchanged')
    need(now['per_feature'][:len(old['per_feature'])] == old['per_feature'] and
         [x['actual'] for x in old['per_feature']] == [1711,3133], 'budget-history', 'preceding4844')
    for k in ('phase_level_items','counting_rule','phase_base_revision','authorization_revision','phase_level_costs','historical_inflight_measurements'):
        need(now[k] == old[k], 'budget-history', k)
    tracked,present = v.paths(); counted=excluded=evidence=0
    for path in sorted(tracked | present):
        if PHASE_BASE not in BASE_BYTES:
            v.base('NIZAM.json', PHASE_BASE)
        before = BASE_BYTES[PHASE_BASE].get(path,b'').decode(errors='replace').splitlines()
        after = v.read(path).decode(errors='replace').splitlines() if path in present else []
        if before == after: continue
        lines = sum((a1-a0)+(b1-b0) for tag,a0,a1,b0,b1 in difflib.SequenceMatcher(None,before,after,autojunk=False).get_opcodes() if tag!='equal')
        if path.startswith('.agent/evidence/') or (path.startswith('.agent/validator/') and not path.endswith('.json')): evidence+=lines
        elif path == '.agent/run_state.json': excluded+=lines
        else:
            need(path in PRODUCTS+PARENT or path == '.agent/contracts/112.json' or re.fullmatch(r'\.agent/(qa|validator)/112(?:-[\w-]+)?\.json',path), 'budget-unclassified',path)
            counted+=lines
    need(4844+counted <= 9360 and counted <= 7266, 'budget-ceiling', str(counted))
    complete = next(x for x in v.obj('.agent/feature_list_015.json')['features'] if x['id']=='112')['status']=='complete'
    need(len(now['per_feature']) == len(old['per_feature'])+(1 if complete else 0), 'budget-history','only112 completion append')
    if complete:
        entry=now['per_feature'][-1]
        need(entry['id']=='112' and entry['estimated']==1200 and entry['actual']==counted and now['total_lines_changed']==4844+counted,
             'budget-measurement','actual completed112 measurement')
    else: need(now['total_lines_changed']==4844,'budget-history','in-flight not appended')
    print(json.dumps({'base':PHASE_BASE,'counted':counted,'evidence':evidence,'excluded':excluded,'prior_completed':4844,'remaining_before112':4516,'prior_only_3x':7266},sort_keys=True))


def seal(v):
    inputs=v.obj(E+'qa-inputs.json')
    need(v.text(E+'qa-inputs.sha256').strip()==sha(v.read(E+'qa-inputs.json')), 'inventory-selfhash', 'separate seal hash')
    need(inputs.get('approved_base')==BASE and inputs.get('approved_contract_sha256')==CONTRACT_HASH,
         'candidate-binding','approved base/contract')
    need(re.fullmatch('[0-9a-f]{40}',inputs.get('candidate_sha','')), 'candidate-binding','actual candidate revision')
    return inputs


def integrity(v):
    contract(v); inputs=seal(v)
    need(set(inputs['source_sha256'])==set(PRODUCTS+['.agent/contracts/112.json']), 'candidate-binding','exact ten source inputs')
    need(set(inputs['verification_sha256'])==set(CHECKER_FILES), 'checker-binding','exact independent bundle')
    for group in ('source_sha256','verification_sha256','immutable_input_sha256'):
        for path,digest in inputs[group].items():
            need(sha(v.read(path))==digest, 'source-binding' if group=='source_sha256' else 'checker-binding' if group=='verification_sha256' else 'historical-immutable',path)
    need(inputs['mode_b_sha256']==sha(v.read('.agent/validator/112-mode-b.json')), 'candidate-binding','ModeB hash')
    modeb=v.obj('.agent/validator/112-mode-b.json')
    need(approved_block(modeb) and modeb.get('reviewed_sha256')==inputs['source_sha256'], 'candidate-binding','ModeB exact source map')
    actors=[inputs.get(k) for k in ('generator','test_author','checker_reviewer','acceptance_reviewer')]
    need(all(isinstance(x,str) and x for x in actors) and len(set(actors))==4, 'review-independence','four distinct actors')
    need(inputs.get('primary_sources_sha256')==sha(v.read(E+'primary-sources.json')), 'primary-source-binding','source manifest')
    need(inputs['immutable_input_sha256'].get(E+'approved-base.json')==sha(v.read(E+'approved-base.json')), 'candidate-binding','approved-base receipt')
    need(inputs['immutable_input_sha256'].get(E+'evidence_gate.py')==sha(v.read(E+'evidence_gate.py')), 'candidate-binding','assessed evidence capture adapter')
    tracked,_=v.paths()
    protected=[p for p in tracked if p.startswith(E) or re.fullmatch(r'\.agent/(?:qa|validator)/112(?:-[\w-]+)?\.json',p)]
    need(set(protected)<=set(inputs['immutable_input_sha256'])|set(inputs['source_sha256']), 'historical-immutable','all prior112 gates/raw inputs covered')


def semantic_review(v):
    inputs=seal(v); review=v.obj(E+'semantic-review.json'); sources=v.obj(E+'primary-sources.json')
    need(review.get('reviewer')==inputs['acceptance_reviewer'] and review.get('personally_reviewed') is True,
         'semantic-independence','fresh acceptance actor personally reviewed')
    need(review.get('candidate_sha')==inputs['candidate_sha'] and review.get('source_sha256')==inputs['source_sha256']
         and review.get('qa_inputs_sha256')==sha(v.read(E+'qa-inputs.json')), 'semantic-binding','exact candidate/source/seal')
    need(approved_block(review), 'semantic-verdict','approved with all blocker arrays empty')
    need(sources.get('collector')==review['reviewer'] and isinstance(sources.get('sources'),list), 'primary-source-binding','personally fetched manifest')
    covered=set(); records={}
    for source in sources['sources']:
        host=urlparse(source['url']).hostname
        need(host in ('www.lispworks.com','www.sbcl.org','sbcl.org','asdf.common-lisp.dev') and source.get('http_status')==200
             and bool(source.get('accessed_at')) and source['path'].startswith(E+'primary/')
             and sha(v.read(source['path']))==source['sha256'] and len(v.read(source['path']))>100,
             'primary-source-binding',source.get('url','missing URL'))
        need(source['url'] not in records,'primary-source-binding','duplicate source URL')
        records[source['url']]=source;covered.update(source.get('topics',[]))
    required=set(v.obj(E+'controls.json')['semantic_topics'])
    need(required<=covered,'semantic-coverage','all official-source topics')
    findings=review.get('findings',[])
    need({x.get('topic') for x in findings}==required,'semantic-coverage','exact review topic set')
    for finding in findings:
        need(finding.get('approved') is True and bool(finding.get('section')) and bool(finding.get('analysis'))
             and finding.get('source_urls') and all(u in records for u in finding['source_urls']),
             'semantic-coverage',finding.get('topic','unnamed'))
        need(finding['section'] in contract(v)['implementation_requirements']['sections'], 'semantic-coverage','actual section heading')
    for path,digest in inputs['source_sha256'].items():
        need(sha(v.read(path))==digest,'semantic-binding',path+' changed after review seal')
    print('Semantic receipt checked for completeness and source binding; semantics personally assessed by '+review['reviewer'])


def negative(v):
    # Positive candidate required before mutations: setup errors cannot stand in for a rejection.
    structure(v); scope(v); historical(v); lifecycle(v); budget(v)
    controls=v.obj(E+'controls.json')
    dispatch={'structure':structure,'scope':scope,'historical':historical,'lifecycle':lifecycle,'budget':budget}
    for control in controls['mutations']:
        with tempfile.TemporaryDirectory(prefix='nizam112-control-') as tmp:
            overlay=Path(tmp); target=overlay/control['path']; target.parent.mkdir(parents=True,exist_ok=True)
            original=v.read(control['path']) if control['kind']!='extra' else None
            borrowed={control['path']:original}
            if control['kind']=='section-comment':
                text=original.decode();heading=control['heading'];start=text.index(heading)+len(heading);m=re.search(r'(?m)^## ',text[start:]);end=start+m.start() if m else len(text)
                mutated=(text[:start]+'\n<!--'+text[start:end]+'-->\n'+text[end:]).encode()
            elif control['kind']=='replace':
                text=original.decode();need(text.count(control['old'])>=1,'control-anchor',control['id']);mutated=text.replace(control['old'],control['new'],1).encode()
            elif control['kind'] in ('move-token','insert-section'):
                text=original.decode();heading=control['heading'];start=text.index(heading)+len(heading);m=re.search(r'(?m)^## ',text[start:]);end=start+m.start() if m else len(text)
                span=text[start:end]
                if control['kind']=='move-token':
                    need(control['token'] in span,'control-anchor',control['id'])
                    span=span.replace(control['token'],'REMOVED_TOKEN')
                    suffix='\n<!--misplaced token '+control['token']+'-->\n'
                else:
                    span+='\n'+control['text']+'\n';suffix=''
                mutated=(text[:start]+span+text[end:]+suffix).encode()
            elif control['kind']=='json':
                obj=json.loads(original);where=obj
                for key in control['keys'][:-1]: where=where[key]
                where[control['keys'][-1]]=control['value'];mutated=json.dumps(obj).encode()
            elif control['kind']=='premature-completion':
                for path in PARENT:
                    borrowed[path]=v.read(path)
                    obj=yaml.safe_load(borrowed[path]) if path.endswith('.yaml') else json.loads(borrowed[path])
                    if path.endswith('feature_list_015.json'):
                        f=next(x for x in obj['features'] if x['id']=='112');f.update(status='complete',passes=True)
                    elif path.endswith('phase_015.yaml'):
                        next(x for x in obj['steps'] if x['id']=='112')['status']='COMPLETED'
                    elif path.endswith('backlog_dag.json'):
                        f=next(x for x in obj['packets'] if x['id']=='NIP3-112');f['status']='complete';f['prerequisites']['evidence']['satisfied']=True
                        next(x for x in obj['packets'] if x['id']=='NIP3-113')['prerequisites']['technical']['satisfied']=True
                    elif path.endswith('run_state.json'):
                        obj['current_feature']='113';obj['active_contract_id']=None;obj['completed_contract_ids'].append('112')
                    p=overlay/path;p.parent.mkdir(parents=True,exist_ok=True)
                    p.write_bytes((yaml.safe_dump(obj,sort_keys=False) if path.endswith('.yaml') else json.dumps(obj)).encode())
                mutated=target.read_bytes()
            elif control['kind']=='extra': mutated=b'undeclared112 source\n'
            else: raise Rejection('control-definition',control['id'])
            target.write_bytes(mutated); private=View(overlay)
            try: dispatch[control['mode']](private)
            except Rejection as exc:
                need(exc.code==control['diagnostic'],'control-diagnostic',control['id']+' expected '+control['diagnostic']+' observed '+exc.code)
                print('CONTROL '+control['id']+' EXIT:1 diagnostic:'+exc.code)
            else: raise Rejection('control-false-pass',control['id'])
            for path,data in borrowed.items():
                if data is None: (overlay/path).unlink()
                else: (overlay/path).write_bytes(data)
            dispatch[control['mode']](View(overlay))
            need(original is None or target.read_bytes()==original,'control-restoration',control['id'])
            print('RESTORED '+control['id']+' EXIT:0')


def main():
    parser=argparse.ArgumentParser()
    modes={'structure':structure,'semantic-review':semantic_review,'scope':scope,'historical':historical,
           'lifecycle':lifecycle,'budget':budget,'negative':negative,'integrity':integrity}
    group=parser.add_mutually_exclusive_group(required=True)
    for mode in modes: group.add_argument('--'+mode,action='store_true')
    args=parser.parse_args()
    mode=next(k for k in modes if getattr(args,k.replace('-','_')))
    try:
        modes[mode](View()); print('PASS112 '+mode); return 0
    except Rejection as exc:
        print('FAIL112 '+exc.code+': '+exc.detail); return 1
    except (KeyError,ValueError,TypeError,OSError,yaml.YAMLError) as exc:
        print('FAIL112 setup-error: '+type(exc).__name__+': '+str(exc)); return 2


if __name__=='__main__':
    sys.exit(main())
